package card;

public class GoToJailCard extends Card{

		public GoToJailCard(String description) {
			super(description);
		}

	}
