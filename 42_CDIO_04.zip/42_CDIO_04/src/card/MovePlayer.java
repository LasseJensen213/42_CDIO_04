package card;

public class MovePlayer extends Card {

	public MovePlayer(String description) {
		super(description);
	}

}
