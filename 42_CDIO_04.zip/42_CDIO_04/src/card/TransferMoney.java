package card;

public class TransferMoney extends Card{

	public TransferMoney(String description) {
		super(description);
	}

}
