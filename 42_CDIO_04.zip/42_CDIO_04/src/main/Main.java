package main;

import mainMenu.MainMenuController;

public class Main {

	
	
	public static void main(String[] args)
	{
		MainMenuController menu = new MainMenuController();
		menu.MainMenu();
	}

}
